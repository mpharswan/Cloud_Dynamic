<p align="center">
  <img src="./assets/images/fiverr_logo.png" width="150"/>
  
</p>
<h1 align="center">FiverrClone</h1>

<p align="center">
    <img src="https://img.shields.io/badge/Awesome-Flutter-%231389fd?style=for-the-badge"/>
    <img src="https://img.shields.io/github/issues/pasanjg/FiverrClone?style=for-the-badge"/>
    <img src="https://img.shields.io/github/forks/pasanjg/FiverrClone?style=for-the-badge"/>
    <img src="https://img.shields.io/github/stars/pasanjg/FiverrClone?style=for-the-badge"/>
    <img src="https://img.shields.io/github/license/pasanjg/FiverrClone?style=for-the-badge"/>
</p>

Fiverr mobile app made with [Flutter](https://flutter.dev/)

More updates are yet to come :heart_eyes:

## Screenshots  

<table>
  <tr>
    <td><img src="./assets/screenshots/1.png"/></td>
    <td><img src="./assets/screenshots/2.png"/></td>
    <td><img src="./assets/screenshots/3.png"/></td>
    <td><img src="./assets/screenshots/4.png"/></td>
    <td><img src="./assets/screenshots/5.png"/></td>
  </tr>
  <tr>
    <td><img src="./assets/screenshots/6.png"/></td>
    <td><img src="./assets/screenshots/7.png"/></td>
    <td><img src="./assets/screenshots/8.png"/></td>
    <td><img src="./assets/screenshots/9.png"/></td>
    <td><img src="./assets/screenshots/10.png"/></td>
  </tr>
</table>
